<?php

$i18n = array(
    'MULTIBLOCK' => 'MutliBlock',
    'MULTIBLOCKSETTINGS' => 'MutliBlock Settings',
	
    'SECTION' 		=> 'Section',
    'ADDNEWCATEGORY' => 'Add new Section',
    'CATEGORYNAMEPLACEHOLDER' => 'Section name',
    'GENERALBTN'	=> 'General',
    'TEMPLATEBTN' 	=> 'Template',
    'BACKBTN'		=> 'Back to Section List',
    'ADDNEWBTN' 	=> 'Add new field',
    'ADDNEWBTN2' 	=> 'Add New',

    'ID' 			=> 'ID',
    'FIELDNAME' 	=> 'Field Name',
    'SLUG' 			=> 'Slug',
    'DEFAULTVALUE' 	=> 'Default Value',
    'FIELDTYPE' 	=> 'Field Type',

    'TEMPLATE1' 	=> 'Placeholder codes for display in page templates',
    'TEMPLATE2' 	=> 'Default Placeholder:',
    'TEMPLATE3' 	=> 'Wysiwyg Placeholder:',
    'TEMPLATE4' 	=> 'If you want to force list order (default is random), place in root element of template:',
    'TEMPLATE5' 	=> 'Place this into page template:',
    'TEMPLATE6' 	=> 'Place this if you want to force list order:',
    'SAVECAT' 		=> 'Save Section',
    'DELETE' 		=> 'Delete',
    'EDIT' 			=> 'Edit',
    'EDITBLOCK' 	=> 'Edit Block',
    'BLOCKTITLE' 	=> 'Block Title',
    'OPTIONS' 		=> 'Options',
    'CHOOSEIMAGE' 	=> 'Choose image...',
    'UPDATE' 		=> 'Update',
    'SAVEORDER' 	=> 'Save order',
    'MULTIBLOCKSECTION' => 'MultiBlock Sections',
    'MULTIBLOCKIN' 	=> 'Blocks in this Section:',
    'CHOOSESECTION' => 'Choose Section',
    'PAYPAL'		=> 'Support my work via PayPal :) Thanks!',
  );

;?>